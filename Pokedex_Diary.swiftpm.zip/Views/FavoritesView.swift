import SwiftUI

struct FavoritesView: View {
    var body: some View {
        ZStack {
            Circle()
        }
    }
}
